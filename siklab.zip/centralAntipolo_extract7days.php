<?php
require_once('config.php'); // Include your database configuration
require_once 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\AutoFilter\Column;

session_start();

if (isset($_SESSION['user_id'])) {
    if (isset($_POST['extract7days'])) {
        // Check if $_SESSION['barangay'] is set and not empty
        if (isset($_SESSION['barangay']) && !empty($_SESSION['barangay'])) {
            // Sanitize the session value to prevent SQL injection
            $barangay = mysqli_real_escape_string($mysqli, $_SESSION['barangay']);

            // Calculate the date 7 days ago
            $sevenDaysAgo = date('Y-m-d', strtotime('-7 days'));

            // Query to extract reports for the past 7 days in the specified barangay
            $query = "SELECT * FROM reports WHERE barangay = '$barangay' AND timeStamp >= '$sevenDaysAgo'";
            $result = mysqli_query($mysqli, $query);

            if ($result) {
                // Create a new Spreadsheet
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                // Set headers for the Excel file
                $sheet->setCellValue('A1', 'Report ID');
                $sheet->setCellValue('B1', 'User ID');
                $sheet->setCellValue('C1', 'Contact Number');
                $sheet->setCellValue('D1', 'Date and Time');
                $sheet->setCellValue('E1', 'Barangay');
                $sheet->setCellValue('F1', 'Address');
                $sheet->setCellValue('G1', 'Special Assistance');
                $sheet->setCellValue('H1', 'Status');
                $sheet->setCellValue('I1', 'Alarm Severity');
                $row = 2;

                // Display the retrieved reports
                while ($report = mysqli_fetch_assoc($result)) {
                    $sheet->setCellValue('A' . $row, $report['reportID']);
                    $sheet->setCellValue('B' . $row, $report['userID']);
                    $sheet->setCellValue('C' . $row, $report['contactNum']);
                    $sheet->setCellValue('D' . $row, $report['timeStamp']);
                    $sheet->setCellValue('E' . $row, $report['barangay']);
                    $sheet->setCellValue('F' . $row, $report['addressRep']);
                    $sheet->setCellValue('G' . $row, $report['assistanceRep']);
                    $sheet->setCellValue('H' . $row, $report['status']);
                    $sheet->setCellValue('I' . $row, $report['alarmSeverity']);
                    
                    // Text Wrap
                    $sheet->getStyle('A' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('B' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('C' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('D' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('E' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('F' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('G' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('H' . $row)->getAlignment()->setWrapText(true);
                    $sheet->getStyle('I' . $row)->getAlignment()->setWrapText(true);
                    $row++;
                }
                // Auto-size columns based on content
                foreach (range('A', 'Z') as $column) {
                    $spreadsheet->getActiveSheet()->getColumnDimension($column)->setAutoSize(true);
                }
                
                // Create a writer for XLSX format
                $writer = new Xlsx($spreadsheet);

                // Define a file name for the Excel file
                $filename = 'extracted_reports.xlsx';

                // Set response headers to trigger a download
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment; filename="' . $filename . '"');

                // Output the Excel file
                $writer->save('php://output');
                exit;
            } else {
                echo 'Error retrieving reports.';
            }
        }
    }
}
?>
